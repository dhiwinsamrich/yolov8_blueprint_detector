# door-window-detection > 2025-05-28 11:41am
https://universe.roboflow.com/dhiwin/door-window-detection-mnwns

Provided by a Roboflow user
License: CC BY 4.0

